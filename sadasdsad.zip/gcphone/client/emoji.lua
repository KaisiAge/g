emoji = {
	{
		{":grin:"},
		"😀"
	}, {
		{":grin2:"},
		"😁"
	}, {
		{":glæde:"},
		"😂"
	}, {
		{":smil2:"},
		"😃"
	}, {
		{":smil3:"},
		"😄"
	},  {
		{":grin3:"},
		"😆"
	}, {
		{":uskyldig:"},
		"😇"
	}, {
		{":blik:"},
		"😉"
	}, {
		{":rødmer:"},
		"😊"
	}, {
		{":smil:"},
		"🙂"
	}, {
		{":tunge4:"},
		"😋"
	}, {
		{":love:"},
		"😍"
	}, {
		{":kys:"},
		"😘"
	}, {
		{":kys2:"},
		"😗"
	}, {
		{":kys3:"},
		"😙"
	}, {
		{":kys4:"},
		"😚"
	}, {
		{":tunge2:"},
		"😜"
	}, {
		{":tunge3:"},
		"😝"
	}, {
		{":tunge:"},
		"😛"
	}, {
		{":dollarface:", ":penge:"},
		"🤑"
	}, {
		{":nørd:", ":nerd:"},
		"🤓"
	}, {
		{":solbriller:"},
		"😎"
	}, {
		{":krammer:"},
		"🤗"
	}, {
		{":flirt:"},
		"😏"
	}, {
		{":utilfreds:"},
		"😒"
	}, {
		{":rullerøjne:"},
		"🙄"
	}, {
		{":hmm:"},
		"🤔"
	}, {
		{":genert:"},
		"😳"
	}, {
		{":skuffet:"},
		"😞"
	}, {
		{":bekymret:"},
		"😟"
	}, {
		{":sur:", ":vred:"},
		"😠"
	}, {
		{":toxic:", ":gal:", ":rasende:"},
		"😡"
	}, {
		{":ked:"},
		"😔"
	}, {
		{":mut:"},
		"🙁"
	}, {
		{":gab:"},
		"😩"
	}, {
		{":overrasket:"},
		"😮"
	}, {
		{":skræmt:"},
		"😱"
	},   {
		{":bange:"},
		"😯"
	}, {
		{":græder:"},
		"😢"
	}, {
		{":skuffet2:"},
		"😥"
	},  {
		{":sved:"},
		"😓"
	}, {
		{":græder2:"},
		"😭"
	}, {
		{":zzz2:"},
		"😴"
	}, {
		{":zzz:"},
		"💤"
	}, {
		{":poop:", ":shit:", ":hankey:", ":poo:"},
		"💩"
	}, {
		{":skull:", ":skeleton:", ":skelet:"},
		"💀"
	}, {
		{":ghost:", ":spøgelse:"},
		"👻"
	}, {
		{":alien:"},
		"👽"
	}, {
		{":robot:", ":robot_face:"},
		"🤖"
	},  {
		{":kat:"},
		"😸"
	}, {
		{":unicorn:", ":unicorn_face:", ":enhjørning:"},
		"🦄"
	},
	{
		{":hotdog:", ":hot_dog:"},
		"🌭"
	}, {
		{":pizza:"},
		"🍕"
	},
	{
		{":taco:"},
		"🌮"
	}, {
		{":burrito:"},
		"🌯"
	},
	{
		{":agurk:"},
		"🥒"
	},
	{
		{":kaffe:"},
		"☕"
	}, 
	 {
		{":øl:"},
		"🍺"
	}, 
	{
		{":slikkepind:"},
		"🍭"
	},
	{
		{":dk:", ":flag:"},
		"🇩🇰"
	},{
		{":gay_pride_flag:", ":rainbow_flag:", ":rainbow:"},
		"🏳️‍🌈"
	}
}